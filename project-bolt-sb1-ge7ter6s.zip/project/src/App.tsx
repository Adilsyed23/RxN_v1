import React from 'react';
import { Search, Star, MessageCircle, Award, MapPin, Mail, Phone, Facebook, Instagram, Twitter, Linkedin } from 'lucide-react';

const experts = Array(8).fill({
  name: 'Nishant Saini',
  title: 'Product Designer',
  rating: 5,
  verified: true,
  image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80'
});

function App() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="border-b">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-xl font-bold">Reco Experts</h1>
              <p className="text-sm text-gray-500">Find a R&D Expert of your needs</p>
            </div>
            <button className="text-blue-600 hover:text-blue-700">
              Get notified for new recommendations
            </button>
          </div>
        </div>
        
        {/* Prominent Search Bar with Background */}
        <div className="bg-blue-50 py-8">
          <div className="relative max-w-4xl mx-auto px-4">
            <input
              type="text"
              placeholder="Search by Name, Skill, Expert Type, City"
              className="w-full pl-12 pr-36 py-4 border-2 rounded-xl shadow-lg focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-lg bg-white"
            />
            <Search className="absolute left-8 top-1/2 -translate-y-1/2 h-6 w-6 text-gray-400" />
            <button className="absolute right-6 top-1/2 -translate-y-1/2 bg-blue-600 text-white px-8 py-2.5 rounded-lg hover:bg-blue-700 transition-colors">
              Search
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8 flex gap-8">
        {/* Filters */}
        <div className="w-64 flex-shrink-0">
          <div className="space-y-4">
            <div>
              <h3 className="font-medium mb-2">Filters</h3>
              <select className="w-full border rounded-lg p-2">
                <option>Domain/Skills</option>
              </select>
            </div>
            <div>
              <select className="w-full border rounded-lg p-2">
                <option>Years of Experience</option>
              </select>
            </div>
            <div>
              <select className="w-full border rounded-lg p-2">
                <option>College</option>
              </select>
            </div>
            <div>
              <select className="w-full border rounded-lg p-2">
                <option>Company</option>
              </select>
            </div>
            <div>
              <select className="w-full border rounded-lg p-2">
                <option>R&D Score</option>
                <option value="5">5 & above</option>
                <option value="4">4 & above</option>
                <option value="3">3 & above</option>
                <option value="2">2 & above</option>
                <option value="1">1 & above</option>
              </select>
            </div>
          </div>
        </div>

        {/* Expert List */}
        <div className="flex-1">
          <div className="space-y-4">
            {experts.map((expert, index) => (
              <div key={index} className="border rounded-lg p-4 flex items-start gap-4">
                <img
                  src={expert.image}
                  alt={expert.name}
                  className="w-12 h-12 rounded-full"
                />
                <div className="flex-1">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-medium">{expert.name}</h3>
                      <p className="text-sm text-gray-600">{expert.title}</p>
                    </div>
                    <div className="flex items-center gap-1">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      <span className="text-sm">5</span>
                    </div>
                  </div>
                  <div className="mt-2 flex gap-4">
                    <button className="text-blue-600 hover:text-blue-700 text-sm flex items-center gap-1">
                      <MessageCircle className="h-4 w-4" />
                      Reply
                    </button>
                    <button className="text-blue-600 hover:text-blue-700 text-sm flex items-center gap-1">
                      <Award className="h-4 w-4" />
                      Badge created expert
                    </button>
                    <button className="text-blue-600 hover:text-blue-700 text-sm flex items-center gap-1">
                      <Star className="h-4 w-4" />
                      Mentoring
                    </button>
                  </div>
                </div>
                <button className="text-blue-600 hover:text-blue-700 text-sm">
                  View profile
                </button>
              </div>
            ))}
          </div>
          <button className="mt-4 text-blue-600 hover:text-blue-700 text-center w-full">
            View 32 more
          </button>

          {/* No Results Section */}
          <div className="mt-8 text-center border-t pt-8">
            <h2 className="font-medium mb-2">Didn't find a R&D Expert?</h2>
            <p className="text-sm text-gray-600 mb-4">
              Share your requirement with our network and let them recommend experts.
              Members will be notified and they can recommend matching experts.
            </p>
            <button className="text-blue-600 hover:text-blue-700">
              Add your requirement on R&D Desk
            </button>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t mt-16">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="grid grid-cols-4 gap-8">
            <div>
              <h2 className="font-bold mb-4">Logo</h2>
              <p className="text-sm text-gray-600 mb-4">
                We are expert team of R&D consultants worldwide.
                Join us to start your journey as R&D expert.
              </p>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Phone className="h-4 w-4" />
                  <span className="text-sm">+91 80808 80808</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4" />
                  <span className="text-sm">contact@outlook.com</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  <span className="text-sm">700 W, CT 06810</span>
                </div>
              </div>
            </div>
            <div>
              <h3 className="font-medium mb-4">About</h3>
              <ul className="space-y-2 text-sm">
                <li>About Us</li>
                <li>Blog</li>
                <li>Careers</li>
                <li>Contact</li>
              </ul>
            </div>
            <div>
              <h3 className="font-medium mb-4">Support</h3>
              <ul className="space-y-2 text-sm">
                <li>Contact Us</li>
                <li>Online Chat</li>
                <li>Whatsapp</li>
                <li>Telegram</li>
              </ul>
            </div>
            <div>
              <h3 className="font-medium mb-4">FAQ</h3>
              <ul className="space-y-2 text-sm">
                <li>Account</li>
                <li>Manage Deliveries</li>
                <li>Orders</li>
                <li>Payments</li>
              </ul>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t flex justify-between items-center">
            <p className="text-sm text-gray-600">© 2024 Reco. All Rights Reserved</p>
            <div className="flex gap-4">
              <Facebook className="h-5 w-5 text-gray-600" />
              <Instagram className="h-5 w-5 text-gray-600" />
              <Twitter className="h-5 w-5 text-gray-600" />
              <Linkedin className="h-5 w-5 text-gray-600" />
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;